package com.nfcbeam.app.ui

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nfcbeam.app.R
import com.nfcbeam.app.databinding.ActivityDeviceListBinding
import com.nfcbeam.app.databinding.ItemDeviceBinding

class DeviceListActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val MODE_SEND = "mode_send"
        const val MODE_RECEIVE = "mode_receive"
        const val EXTRA_DEVICE_ADDRESS = "extra_device_address"
    }

    private lateinit var binding: ActivityDeviceListBinding
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private val deviceList = mutableListOf<BluetoothDevice>()
    private lateinit var deviceAdapter: DeviceAdapter
    private var mode: String = MODE_SEND

    // Broadcast receiver for discovered devices
    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU)
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        else
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

                    device?.let {
                        if (!deviceList.any { d -> d.address == it.address }) {
                            deviceList.add(it)
                            deviceAdapter.notifyItemInserted(deviceList.size - 1)
                        }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnScan.isEnabled = true
                    if (deviceList.isEmpty()) {
                        binding.tvEmpty.visibility = View.VISIBLE
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.btnScan.isEnabled = false
                    binding.tvEmpty.visibility = View.GONE
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeviceListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_SEND

        val btManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = btManager.adapter

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        registerReceiver()
        loadPairedDevices()

        // Eğer alma modundaysa direkt receiver'ı başlat
        if (mode == MODE_RECEIVE) {
            startReceiveMode()
        }
    }

    private fun setupToolbar() {
        supportActionBar?.apply {
            title = if (mode == MODE_SEND)
                getString(R.string.select_device_to_send)
            else
                getString(R.string.waiting_for_connection)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setupRecyclerView() {
        deviceAdapter = DeviceAdapter(deviceList) { device ->
            onDeviceSelected(device)
        }
        binding.recyclerDevices.apply {
            layoutManager = LinearLayoutManager(this@DeviceListActivity)
            adapter = deviceAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnScan.setOnClickListener {
            startDiscovery()
        }

        if (mode == MODE_RECEIVE) {
            binding.btnScan.text = getString(R.string.make_discoverable)
            binding.btnScan.setOnClickListener {
                makeDiscoverable()
            }
        }
    }

    private fun loadPairedDevices() {
        try {
            val pairedDevices = bluetoothAdapter.bondedDevices
            pairedDevices?.forEach { device ->
                if (!deviceList.any { it.address == device.address }) {
                    deviceList.add(device)
                }
            }
            deviceAdapter.notifyDataSetChanged()
            binding.tvPairedHeader.visibility =
                if (deviceList.isNotEmpty()) View.VISIBLE else View.GONE
        } catch (e: SecurityException) {
            Toast.makeText(this, getString(R.string.bt_permission_denied), Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDiscovery() {
        deviceList.clear()
        deviceAdapter.notifyDataSetChanged()
        loadPairedDevices()
        try {
            if (bluetoothAdapter.isDiscovering) {
                bluetoothAdapter.cancelDiscovery()
            }
            bluetoothAdapter.startDiscovery()
        } catch (e: SecurityException) {
            Toast.makeText(this, getString(R.string.bt_permission_denied), Toast.LENGTH_SHORT).show()
        }
    }

    private fun makeDiscoverable() {
        val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
            putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        }
        startActivity(discoverableIntent)
    }

    private fun startReceiveMode() {
        val intent = Intent(this, TransferActivity::class.java).apply {
            putExtra(TransferActivity.EXTRA_MODE, TransferActivity.MODE_RECEIVE)
        }
        startActivity(intent)
        finish()
    }

    private fun onDeviceSelected(device: BluetoothDevice) {
        try {
            bluetoothAdapter.cancelDiscovery()
        } catch (e: SecurityException) { /* ignore */ }

        val intent = Intent(this, TransferActivity::class.java).apply {
            putExtra(TransferActivity.EXTRA_MODE, TransferActivity.MODE_SEND)
            putExtra(TransferActivity.EXTRA_DEVICE_ADDRESS, device.address)
            putExtra(TransferActivity.EXTRA_DEVICE_NAME, try { device.name } catch (e: SecurityException) { device.address })
        }
        startActivity(intent)
        finish()
    }

    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        registerReceiver(discoveryReceiver, filter)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(discoveryReceiver)
            bluetoothAdapter.cancelDiscovery()
        } catch (e: Exception) { /* ignore */ }
    }

    // ---------------------------------------------------------------
    // RecyclerView Adapter
    // ---------------------------------------------------------------
    inner class DeviceAdapter(
        private val devices: List<BluetoothDevice>,
        private val onClick: (BluetoothDevice) -> Unit
    ) : RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

        inner class DeviceViewHolder(val binding: ItemDeviceBinding) :
            RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
            val b = ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return DeviceViewHolder(b)
        }

        override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
            val device = devices[position]
            try {
                holder.binding.tvDeviceName.text = device.name ?: getString(R.string.unknown_device)
            } catch (e: SecurityException) {
                holder.binding.tvDeviceName.text = getString(R.string.unknown_device)
            }
            holder.binding.tvDeviceAddress.text = device.address
            holder.binding.root.setOnClickListener { onClick(device) }
        }

        override fun getItemCount() = devices.size
    }
}
