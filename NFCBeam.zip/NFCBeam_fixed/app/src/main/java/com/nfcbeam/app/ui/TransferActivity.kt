package com.nfcbeam.app.ui

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.nfcbeam.app.R
import com.nfcbeam.app.bluetooth.BluetoothTransferService
import com.nfcbeam.app.bluetooth.TransferListener
import com.nfcbeam.app.databinding.ActivityTransferBinding

class TransferActivity : AppCompatActivity(), TransferListener {

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_DEVICE_ADDRESS = "extra_device_address"
        const val EXTRA_DEVICE_NAME = "extra_device_name"
        const val MODE_SEND = "mode_send"
        const val MODE_RECEIVE = "mode_receive"
    }

    private lateinit var binding: ActivityTransferBinding
    private var transferService: BluetoothTransferService? = null
    private var isBound = false
    private var mode: String = MODE_SEND
    private var deviceAddress: String? = null
    private var deviceName: String? = null
    private var selectedFileUri: Uri? = null

    // File picker
    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedFileUri = it
            val name = getFileName(it)
            binding.tvSelectedFile.text = name
            binding.tvSelectedFile.visibility = View.VISIBLE
            binding.btnStartSend.isEnabled = true
        }
    }

    // Service connection
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val localBinder = binder as BluetoothTransferService.LocalBinder
            transferService = localBinder.getService()
            transferService?.setListener(this@TransferActivity)
            isBound = true

            // Start the correct mode after binding
            when (mode) {
                MODE_SEND -> deviceAddress?.let { transferService?.connectToDevice(it) }
                MODE_RECEIVE -> transferService?.startServer()
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            transferService = null
            isBound = false
        }
    }

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransferBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_SEND
        deviceAddress = intent.getStringExtra(EXTRA_DEVICE_ADDRESS)
        deviceName = intent.getStringExtra(EXTRA_DEVICE_NAME)

        setupToolbar()
        setupUi()
        bindTransferService()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            transferService?.setListener(null)
            unbindService(serviceConnection)
        }
    }

    // ---------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------
    private fun setupToolbar() {
        supportActionBar?.apply {
            title = if (mode == MODE_SEND)
                getString(R.string.send_file, deviceName ?: deviceAddress)
            else
                getString(R.string.receive_file)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setupUi() {
        if (mode == MODE_SEND) {
            binding.layoutSend.visibility = View.VISIBLE
            binding.layoutReceive.visibility = View.GONE

            binding.btnPickFile.setOnClickListener {
                filePicker.launch("*/*")
            }

            binding.btnStartSend.isEnabled = false
            binding.btnStartSend.setOnClickListener {
                selectedFileUri?.let { uri ->
                    transferService?.sendFile(uri) ?: run {
                        Toast.makeText(this, getString(R.string.service_not_ready), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else {
            binding.layoutSend.visibility = View.GONE
            binding.layoutReceive.visibility = View.VISIBLE
            binding.tvReceiveStatus.text = getString(R.string.waiting_for_file)
        }
    }

    private fun bindTransferService() {
        val intent = Intent(this, BluetoothTransferService::class.java)
        startService(intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    // ---------------------------------------------------------------
    // TransferListener callbacks (from service, runs on UI thread)
    // ---------------------------------------------------------------
    override fun onConnected(deviceName: String) {
        runOnUiThread {
            binding.tvConnectionStatus.text = getString(R.string.connected_to, deviceName)
            binding.tvConnectionStatus.setTextColor(getColor(R.color.green_500))
            if (mode == MODE_SEND) {
                binding.btnPickFile.isEnabled = true
            }
        }
    }

    override fun onConnecting() {
        runOnUiThread {
            binding.tvConnectionStatus.text = getString(R.string.connecting)
            binding.progressTransfer.visibility = View.VISIBLE
        }
    }

    override fun onDisconnected() {
        runOnUiThread {
            binding.tvConnectionStatus.text = getString(R.string.disconnected)
            binding.tvConnectionStatus.setTextColor(getColor(R.color.red_500))
            binding.progressTransfer.visibility = View.GONE
        }
    }

    override fun onTransferProgress(percent: Int, bytesSent: Long, totalBytes: Long) {
        runOnUiThread {
            binding.progressTransfer.visibility = View.VISIBLE
            binding.progressTransfer.progress = percent
            binding.tvProgress.text = getString(
                R.string.transfer_progress,
                percent,
                formatBytes(bytesSent),
                formatBytes(totalBytes)
            )
        }
    }

    override fun onTransferComplete(filePath: String) {
        runOnUiThread {
            binding.progressTransfer.progress = 100
            binding.tvProgress.text = getString(R.string.transfer_complete)
            binding.tvReceiveStatus.text = getString(R.string.file_saved_to, filePath)
            Toast.makeText(this, getString(R.string.transfer_complete), Toast.LENGTH_LONG).show()
        }
    }

    override fun onTransferFailed(error: String) {
        runOnUiThread {
            binding.tvProgress.text = getString(R.string.transfer_failed, error)
            binding.progressTransfer.visibility = View.GONE
            Toast.makeText(this, getString(R.string.transfer_failed, error), Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------
    private fun getFileName(uri: Uri): String {
        var name = "unknown"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            cursor.moveToFirst()
            name = cursor.getString(nameIndex)
        }
        return name
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
