package com.nfcbeam.app.bluetooth

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Binder
import android.os.Environment
import android.os.IBinder
import kotlinx.coroutines.*
import java.io.*
import java.util.UUID

/**
 * BluetoothTransferService
 *
 * Bluetooth Classic (SPP) üzerinden iki yönlü dosya aktarımı yapar.
 *
 * Protokol (basit başlık + veri):
 *   [8 byte: dosya boyutu (long)]
 *   [2 byte: dosya adı uzunluğu (short)]
 *   [N byte: dosya adı (UTF-8)]
 *   [M byte: dosya verisi]
 */
class BluetoothTransferService : Service() {

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val SERVICE_NAME = "NFCBeam"
        private const val BUFFER_SIZE = 8192
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var listener: TransferListener? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var clientSocket: BluetoothSocket? = null

    // ---------------------------------------------------------------
    // Binder
    // ---------------------------------------------------------------
    inner class LocalBinder : Binder() {
        fun getService(): BluetoothTransferService = this@BluetoothTransferService
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = btManager.adapter
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        closeConnections()
    }

    // ---------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------
    fun setListener(l: TransferListener?) {
        listener = l
    }

    /**
     * SERVER MODE: diğer cihazdan bağlantı bekle ve dosya al
     */
    fun startServer() {
        serviceScope.launch {
            try {
                listener?.onConnecting()
                @Suppress("MissingPermission")
                serverSocket = bluetoothAdapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID)
                val socket = serverSocket?.accept() ?: return@launch
                clientSocket = socket
                serverSocket?.close()

                @Suppress("MissingPermission")
                val remoteName = socket.remoteDevice.name ?: socket.remoteDevice.address
                listener?.onConnected(remoteName)

                receiveFile(socket)
            } catch (e: Exception) {
                listener?.onTransferFailed(e.message ?: "Server error")
            }
        }
    }

    /**
     * CLIENT MODE: belirtilen MAC adresine bağlan
     */
    fun connectToDevice(address: String) {
        serviceScope.launch {
            try {
                listener?.onConnecting()
                val device: BluetoothDevice = bluetoothAdapter?.getRemoteDevice(address)
                    ?: run {
                        listener?.onTransferFailed("Device not found")
                        return@launch
                    }

                // Eşleştirilmiş SPP soketi oluştur
                @Suppress("MissingPermission")
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                clientSocket = socket

                @Suppress("MissingPermission")
                bluetoothAdapter?.cancelDiscovery()

                socket.connect()

                @Suppress("MissingPermission")
                val remoteName = device.name ?: address
                listener?.onConnected(remoteName)

            } catch (e: Exception) {
                listener?.onTransferFailed(e.message ?: "Connection failed")
            }
        }
    }

    /**
     * Bağlantı kurulduktan sonra dosya gönder
     */
    fun sendFile(fileUri: Uri) {
        val socket = clientSocket
        if (socket == null || !socket.isConnected) {
            listener?.onTransferFailed("Not connected")
            return
        }

        serviceScope.launch {
            try {
                val inputStream = contentResolver.openInputStream(fileUri)
                    ?: run {
                        listener?.onTransferFailed("Cannot open file")
                        return@launch
                    }

                val fileName = getFileName(fileUri)
                val fileSize = getFileSize(fileUri)

                val out = DataOutputStream(BufferedOutputStream(socket.outputStream))

                // Başlık yaz
                out.writeLong(fileSize)
                val nameBytes = fileName.toByteArray(Charsets.UTF_8)
                out.writeShort(nameBytes.size)
                out.write(nameBytes)
                out.flush()

                // Veri gönder
                val buffer = ByteArray(BUFFER_SIZE)
                var totalSent = 0L
                var read: Int
                while (inputStream.read(buffer).also { read = it } != -1) {
                    out.write(buffer, 0, read)
                    totalSent += read
                    val percent = if (fileSize > 0) ((totalSent * 100) / fileSize).toInt() else 0
                    listener?.onTransferProgress(percent, totalSent, fileSize)
                }
                out.flush()
                inputStream.close()

                listener?.onTransferComplete(fileName)

            } catch (e: Exception) {
                listener?.onTransferFailed(e.message ?: "Send failed")
            }
        }
    }

    // ---------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------
    private suspend fun receiveFile(socket: BluetoothSocket) {
        try {
            val inp = DataInputStream(BufferedInputStream(socket.inputStream))

            // Başlık oku
            val fileSize = inp.readLong()
            val nameLength = inp.readShort().toInt()
            val nameBytes = ByteArray(nameLength)
            inp.readFully(nameBytes)
            val fileName = String(nameBytes, Charsets.UTF_8)

            // Çıktı dizini
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val outFile = File(downloadsDir, "NFCBeam_$fileName")
            val outStream = FileOutputStream(outFile)

            val buffer = ByteArray(BUFFER_SIZE)
            var totalReceived = 0L
            var read: Int

            while (totalReceived < fileSize) {
                val remaining = (fileSize - totalReceived).coerceAtMost(BUFFER_SIZE.toLong()).toInt()
                read = inp.read(buffer, 0, remaining)
                if (read == -1) break
                outStream.write(buffer, 0, read)
                totalReceived += read
                val percent = ((totalReceived * 100) / fileSize).toInt()
                listener?.onTransferProgress(percent, totalReceived, fileSize)
            }

            outStream.close()
            listener?.onTransferComplete(outFile.absolutePath)

        } catch (e: Exception) {
            listener?.onTransferFailed(e.message ?: "Receive failed")
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "received_file"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(idx)
            }
        }
        return name
    }

    private fun getFileSize(uri: Uri): Long {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (idx >= 0 && cursor.moveToFirst()) {
                return cursor.getLong(idx)
            }
        }
        return -1L
    }

    private fun closeConnections() {
        try { clientSocket?.close() } catch (e: Exception) { }
        try { serverSocket?.close() } catch (e: Exception) { }
    }
}

// ---------------------------------------------------------------
// Listener interface
// ---------------------------------------------------------------
interface TransferListener {
    fun onConnected(deviceName: String)
    fun onConnecting()
    fun onDisconnected()
    fun onTransferProgress(percent: Int, bytesSent: Long, totalBytes: Long)
    fun onTransferComplete(filePath: String)
    fun onTransferFailed(error: String)
}
