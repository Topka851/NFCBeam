package com.nfcbeam.app.ui

import android.Manifest
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.nfc.NfcManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.nfcbeam.app.R
import com.nfcbeam.app.databinding.ActivityMainBinding
import com.nfcbeam.app.nfc.NfcHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var nfcAdapter: NfcAdapter? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private lateinit var nfcPendingIntent: PendingIntent

    // ---------------------------------------------------------------
    // Permission launcher
    // ---------------------------------------------------------------
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            updateUiState()
        } else {
            Toast.makeText(this, getString(R.string.permissions_required), Toast.LENGTH_LONG).show()
        }
    }

    private val enableBluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        updateUiState()
    }

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupAdapters()
        setupNfcPendingIntent()
        setupClickListeners()
        requestRequiredPermissions()
        updateUiState()

        // App may have been launched FROM an NFC tag tap
        handleNfcIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this, nfcPendingIntent, null, null)
        updateUiState()
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleNfcIntent(intent)
    }

    // ---------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------
    private fun setupAdapters() {
        val nfcManager = getSystemService(NFC_SERVICE) as NfcManager
        nfcAdapter = nfcManager.defaultAdapter

        val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
    }

    private fun setupNfcPendingIntent() {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT

        nfcPendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
    }

    private fun setupClickListeners() {
        // Send file button
        binding.btnSend.setOnClickListener {
            if (!hasBluetoothPermissions()) {
                requestRequiredPermissions()
                return@setOnClickListener
            }
            ensureBluetoothEnabled {
                openDeviceList(mode = DeviceListActivity.MODE_SEND)
            }
        }

        // Receive file button
        binding.btnReceive.setOnClickListener {
            if (!hasBluetoothPermissions()) {
                requestRequiredPermissions()
                return@setOnClickListener
            }
            ensureBluetoothEnabled {
                openDeviceList(mode = DeviceListActivity.MODE_RECEIVE)
            }
        }

        // NFC write button
        binding.btnWriteNfc.setOnClickListener {
            showNfcWriteDialog()
        }
    }

    // ---------------------------------------------------------------
    // NFC Handling
    // ---------------------------------------------------------------
    private fun handleNfcIntent(intent: Intent) {
        when (intent.action) {
            NfcAdapter.ACTION_NDEF_DISCOVERED,
            NfcAdapter.ACTION_TAG_DISCOVERED,
            NfcAdapter.ACTION_TECH_DISCOVERED -> {
                Toast.makeText(this, getString(R.string.nfc_detected), Toast.LENGTH_SHORT).show()
                // NFC tetiklemesi → otomatik olarak dosya gönderme ekranına geç
                ensureBluetoothEnabled {
                    openDeviceList(mode = DeviceListActivity.MODE_SEND)
                }
            }
        }
    }

    private fun showNfcWriteDialog() {
        if (nfcAdapter == null) {
            Toast.makeText(this, getString(R.string.nfc_not_supported), Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.write_nfc_tag))
            .setMessage(getString(R.string.write_nfc_message))
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                NfcHelper.startNfcWrite(this, nfcAdapter!!)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ---------------------------------------------------------------
    // Bluetooth
    // ---------------------------------------------------------------
    private fun ensureBluetoothEnabled(onEnabled: () -> Unit) {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, getString(R.string.bt_not_supported), Toast.LENGTH_SHORT).show()
            return
        }
        if (!bluetoothAdapter!!.isEnabled) {
            val enableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetoothLauncher.launch(enableIntent)
        } else {
            onEnabled()
        }
    }

    private fun openDeviceList(mode: String) {
        val intent = Intent(this, DeviceListActivity::class.java)
        intent.putExtra(DeviceListActivity.EXTRA_MODE, mode)
        startActivity(intent)
    }

    // ---------------------------------------------------------------
    // Permissions
    // ---------------------------------------------------------------
    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            permissions += Manifest.permission.BLUETOOTH
            permissions += Manifest.permission.BLUETOOTH_ADMIN
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.READ_MEDIA_IMAGES
            permissions += Manifest.permission.READ_MEDIA_VIDEO
            permissions += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            permissions += Manifest.permission.READ_EXTERNAL_STORAGE
        }

        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (notGranted.isNotEmpty()) {
            permissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    private fun hasBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                    PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) ==
                    PackageManager.PERMISSION_GRANTED
        }
    }

    // ---------------------------------------------------------------
    // UI State
    // ---------------------------------------------------------------
    private fun updateUiState() {
        val nfcAvailable = nfcAdapter != null
        val nfcEnabled = nfcAvailable && nfcAdapter!!.isEnabled
        val btAvailable = bluetoothAdapter != null
        val btEnabled = btAvailable && bluetoothAdapter!!.isEnabled

        binding.statusNfc.text = when {
            !nfcAvailable -> getString(R.string.nfc_not_supported)
            !nfcEnabled   -> getString(R.string.nfc_disabled)
            else          -> getString(R.string.nfc_ready)
        }

        binding.statusBluetooth.text = when {
            !btAvailable -> getString(R.string.bt_not_supported)
            !btEnabled   -> getString(R.string.bt_disabled)
            else         -> getString(R.string.bt_ready)
        }

        binding.indicatorNfc.setBackgroundResource(
            if (nfcEnabled) R.drawable.indicator_green else R.drawable.indicator_red
        )
        binding.indicatorBluetooth.setBackgroundResource(
            if (btEnabled) R.drawable.indicator_green else R.drawable.indicator_red
        )
    }
}
