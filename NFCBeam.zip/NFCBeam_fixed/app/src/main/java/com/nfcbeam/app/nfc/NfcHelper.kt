package com.nfcbeam.app.nfc

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Build
import android.widget.Toast
import com.nfcbeam.app.R

/**
 * NfcHelper
 *
 * NFC etiketine uygulama kimliğini yazar.
 * Etiket başka bir NFCBeam cihazına dokunulduğunda
 * MainActivity'yi otomatik olarak açar.
 */
object NfcHelper {

    private var isWriteMode = false

    /**
     * NFC yazma modunu başlatır.
     * Bir sonraki TAG_DISCOVERED intent'inde etikete yazar.
     */
    fun startNfcWrite(activity: Activity, nfcAdapter: NfcAdapter) {
        isWriteMode = true

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT

        val pendingIntent = PendingIntent.getActivity(
            activity, 0,
            Intent(activity, activity.javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        nfcAdapter.enableForegroundDispatch(activity, pendingIntent, null, null)
        Toast.makeText(activity, activity.getString(R.string.hold_nfc_tag), Toast.LENGTH_LONG).show()
    }

    /**
     * Activity.onNewIntent içinden çağrılır.
     * Eğer yazma modundaysak etikete NDEF kaydı yazar.
     */
    fun handleWriteIntent(activity: Activity, intent: Intent): Boolean {
        if (!isWriteMode) return false

        val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        else
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)

        tag?.let {
            return writeNdefTag(activity, it)
        }
        return false
    }

    private fun writeNdefTag(activity: Activity, tag: Tag): Boolean {
        val ndef = Ndef.get(tag) ?: run {
            Toast.makeText(activity, activity.getString(R.string.nfc_not_ndef), Toast.LENGTH_SHORT).show()
            return false
        }

        return try {
            ndef.connect()
            if (!ndef.isWritable) {
                Toast.makeText(activity, activity.getString(R.string.nfc_read_only), Toast.LENGTH_SHORT).show()
                ndef.close()
                return false
            }

            // MIME type record: "application/com.nfcbeam.app"
            val mimeType = "application/com.nfcbeam.app"
            val payload = "NFCBeam".toByteArray(Charsets.UTF_8)
            val record = NdefRecord.createMime(mimeType, payload)
            val message = NdefMessage(arrayOf(record))

            if (ndef.maxSize < message.byteArrayLength) {
                Toast.makeText(activity, activity.getString(R.string.nfc_tag_too_small), Toast.LENGTH_SHORT).show()
                ndef.close()
                return false
            }

            ndef.writeNdefMessage(message)
            ndef.close()
            isWriteMode = false
            Toast.makeText(activity, activity.getString(R.string.nfc_write_success), Toast.LENGTH_SHORT).show()
            true

        } catch (e: Exception) {
            Toast.makeText(activity, activity.getString(R.string.nfc_write_failed, e.message), Toast.LENGTH_LONG).show()
            false
        }
    }
}
